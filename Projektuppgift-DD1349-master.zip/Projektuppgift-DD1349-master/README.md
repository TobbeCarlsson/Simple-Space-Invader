# Projektuppgift-DD1349

## Description

This is a game similar to space invaders. You control a spaceship and have to destroy all of the alien invaders before they reach earth. But beware, you are limited to horizontal movement only, and your foes are legion.

Enemies attack in waves and spawn in rows at the upper part of the screen before they make their way downwards while shooting at you, a smol spaceship at the bottom of the screen. You can move left and right, and you have the ability to fire back at your opponents. Your score increases as you eliminate aliens. Are you enough of a legend to destroy your enemies and land a new high score? 

### Check out what our critics have to say:

"Wow great game" - Vår majestät Knugen

"Never before have you been able to invade so much space in such short time! Fantastic!" - Amanda Hallstedt

"Revolutionary" - Tobias Carlsson

"Cheap and effective alternative to therapy!" - Isak Karlsson

"Det lär väl funka" - Love Lindgren

"Truly a great time to be alive" - Kei Duke Bergman

"Som codenames fast med innuendon" - Julia Wang

"Bättre än EU4s nya DLC" - Fabian Andréasson

"sus amogus game
ඞඞඞඞඞඞඞඞඞඞඞඞඞඞ" - Erik

### Project plan

For our project plan, please view the milestones section of the git repository. The plan consists of weekly milestones each containing a set of issues.


### How to use and compile
This game imports the javax.swing and java.awt packages which should be available in native java. To start the game, run Spaceinvaders.java. You should only need a functioning java compiler to run the main file. However running this file through WSL editions of linux has resulted in unresolved errors.

